import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.util.IllegalFormatException;
import java.util.Scanner;
public class App {
    public static void main(String[] args) throws Exception {
    	
    	
        //Assigment 1
    	int select;
    	System.out.println("Type 1: to input a file that returns all directories and sub directories in your path"+
    	"/n Type 2: to write text into a file"+
    	"/n Type 3: remove a character from a file");
    	//if args is empty
    	if(args[0] == null) {
    		System.out.println("Usage: for file input or writing");
    		throw new IllegalArgumentException();
    	}
        
        try {
        	select = Integer.parseInt(args[0]);
        	
        }
        catch(NumberFormatException nfe) {
        	System.out.printf("%s should be in number formet %n", args[0]);
        	throw nfe;
        }
        
        if( select == 1) {
        	//init scanner
            Scanner scan = new Scanner(System.in);
            System.out.println("Input file path");
            //read string from console
            String _path = scan.nextLine(); 
            //init string as file  object
	        File main_path = new File(_path);
	    
	        if(main_path.exists() && main_path.isDirectory()){
	            File arr[] = main_path.listFiles();
	            printDirectory(arr, 0, 0);
	        }
	        scan.close();
        }
        //selection two should write text into a file
        if(select == 2) {
        	String path = "Input path here ";
        	Scanner user = new Scanner(System.in);
        	
        	String text = "Input text to add to file";
        	System.out.printf("%s",text);
        	text = user.nextLine();
        	
        	System.out.printf("%s",path);
        	path = user.nextLine();
        	
            
            fileWrite(text, path);
        }
        //selection three removes 
        if (select == 3) {
        	
        	Scanner user = new Scanner(System.in);
        	System.out.println("Input file path");
            String read_path = user.nextLine();
            String read_text = readFile(read_path);
            
            countLetter(read_text, 'e');
            
            user.close();
        	
        }


        //Write text into file
        



        //Count letter chosen by user



       


        
    }


    static void printDirectory(File[] arr, int index, int level){
        if(index == arr.length)
            return;
        
        for(int i=0; i  < level; i++)
            System.out.println("\t");
        //check individual file names
        if(arr[index].isFile())
        	//print individuals file names
            System.out.println(arr[index].getName());
        else if(arr[index].isDirectory()){
            System.out.println("[" + arr[index].getName() + "]");
            // recursion for sub-directories
            printDirectory(arr[index].listFiles(), 0, level + 1); 
        }

    }
//String that write data to a file
    static void fileWrite(String data, String path){
    	//change string path to a file object
        File f1 = new File(path);
        
        try
        {
            if(!f1.exists()){
                f1.createNewFile();
            }
            FileWriter fileWriter = new FileWriter(f1.getName(), true);
            BufferedWriter buffer = new BufferedWriter(fileWriter);
            buffer.write(data);
            buffer.close();

        }
        catch(IOException e){
            e.printStackTrace();
        }
        
    }


    static String readFile(String path) throws IOException {
        File _file = new File(path);
        FileReader fw = new FileReader(path); 
        String everything;

        try(BufferedReader br = new BufferedReader(fw)){
            StringBuilder sb = new StringBuilder();
            String line = br.readLine();

            while(line != null){
                sb.append(line);
                sb.append(System.lineSeparator());
                line = br.readLine();
            }

            everything = sb.toString();
        }

        return everything;
    }

    static int countLetter(String line, char letter){
        int count = 0;
        for(int i =0; i < line.length(); i++){
            if(line.charAt(i) == letter){
                count++;
            }

        }
        return count; 
    }


}
