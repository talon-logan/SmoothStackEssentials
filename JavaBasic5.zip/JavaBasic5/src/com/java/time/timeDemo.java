package com.java.time;



import java.time.temporal.TemporalAdjuster;
import java.time.*;

public class timeDemo{
	public static void main(String[] args) {
		
		LocalDate date = LocalDate.now();
		System.out.println(LocalTime.now());
		System.out.println("Which class would you use to store your birthday in years, months, days, seconds, and nanoseconds?");
		System.out.println("Response: Using the Java.time.localDate package");
		//How to find the previous thursday
		System.out.println("The previous Thursday is: %s%n",date.with(TemporalAdjuster.previous(DayOfWeek.THURSDAY)));
		
		/*
		 * Both zone ID and zone offset track and offset from the Greenwich time zones, but   zoneoff set
		 * class tracks only the absolute offset from greenwich. While zoneid uses the zonerule
		 */
		
		
		 //Convert can instant to a zonedDateTime by using the zonedDateTime.ofInstant method. You also need to supple a ZoneID:
		ZonedDateTime zdt = ZonedDateTime.ofInstant(Instant.now(), ZoneId.systemDefault());
		
		
		//Use the to instant method in the chronoonedDate time interface
		//implemented by the zonedDateTime class , to convert from a zoned to a instant
		Instant inst = ZonedDateTime.now().toInstant();
		 
	}
}