package com.java.time;

import java.time.DateTimeException;
import java.time.Month;
import java.time.Year;
import java.time.YearMonth;

public class MonthsInYear {
	public static void main(String[] args) {
		int year = 0;
		//check for empty array
		if(args==null) {
			System.out.println("Usage: Months in Year");
			throw new IllegalArgumentException();
		}
		try {
			year = Integer.parseInt(args[0]);
		}
		//check if its an integer
		catch (NumberFormatException nfe) {
			System.out.printf("s% should be in number format %n", args[0]);
			throw nfe; //rethrow
		}
		try {
			Year date = Year.of(year);
		}//check if its a date
		catch(DateTimeException exc) {
			System.out.printf("%d is not a valid year. %n", year);
			throw exc; //rethrow
		}
		
		System.out.printf("for the year: %n", year);
		for(Month month: Month.values()) {
			YearMonth ym = YearMonth.of(year, month);
			System.out.printf("%s : %d days %n", month, ym.lengthOfMonth());
		}
	}

}
