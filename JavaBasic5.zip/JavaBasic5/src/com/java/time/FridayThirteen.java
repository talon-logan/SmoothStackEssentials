package com.java.time;

import java.time.LocalDate;
import java.time.temporal.ChronoField;
import java.time.temporal.TemporalAccessor;
import java.time.temporal.TemporalQuery;
//implement abstract methods
public class FridayThirteen  implements TemporalQuery<Boolean>{
	
	//add temporal accessor parameter
	public Boolean queryFrom(TemporalAccessor date) {
		return ((date.get(ChronoField.DAY_OF_MONTH)==13)&& 
				(date.get(ChronoField.DAY_OF_WEEK)==5));
	}
	
	
	public static void main(String[] args) {
		FridayThirteen fridayThirteen = new FridayThirteen();
		
		System.out.println(fridayThirteen.queryFrom(LocalDate.now()));
	}


}
