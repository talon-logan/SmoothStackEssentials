package com.lambda.basic;
import java.util.ArrayList;
import java.util.List;

public class Words {
	public String find(List<String> words) {
		List<String> temp = new ArrayList();
	for(int i=0; i < words.size(); i++) {
		if(words.get(i).contains("e")) {
			return words.get(i);
		}
		else {
			temp.add(words.get(i));
		}
			
	}
	
  }
}
	

