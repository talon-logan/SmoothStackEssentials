package com.lambda.basic;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.*;

public class LambdaDemo {
	
	public static void main(String[] args) {
	    List<String> words = new ArrayList();
		words.add("Apple");
		words.add("Meal");
		words.add("Eyes");
		words.add("Squint");
		words.add("fix");
		Words util = new Words();
		
		List<Integer> num = new ArrayList();
		for(int i = 1; i != 10; i++) {
			num.add(i*13);
		}
		
		
		
		System.out.println("Order from shortest to longest");
		words.sort((i,j)->(i.length()-j.length()));
		words.forEach(word -> {System.out.println(word);});
		
		System.out.println();
		
		
		System.out.println("Order from longest to shortest");
		words.sort((i,j)->(j.length()-i.length()));
		words.forEach(word -> {System.out.println(word);});
		
		System.out.println();
		
		
		System.out.println("Print by First Character");
		words.sort((i,j) -> i.compareTo(j));
		words.forEach(word -> {System.out.println(word);});
		
		System.out.println();
		
		
		System.out.println("Print only letters that contain E");
		words.stream().filter(word->word.contains("e")).forEach(System.out::println);
		
		//Arrays.sort(words, util.find(words));
		
		
		
		System.out.println();
		
		
		System.out.println("Write a function that adds an 'e' to even numbers and an 'o' to odd number");
		System.out.println(getString(num));
		
		System.out.println();
		
		System.out.println("Write a function that removes all words that start with a given letter, and size");
		System.out.println(getList(words,"a",5));
		
		System.out.println();
		
		
		System.out.println("Write a function that removes the right most digit from an array of values ");
		System.out.println(rightDigit(num));
		
		System.out.println();
		
		
		System.out.println("Write a function that multiplies all values in an array by 2 ");
		System.out.println(multiplyTwo(num));
		
		System.out.println();
		
		System.out.println("Write a function that removes all the x's from a list of strings");
		System.out.println(removeX(words));
		
		
		System.out.println("Recusive function to add values to target");
		int [] nums = {2, 3, 3, 6};
		System.out.println(lumpSum(0,nums, 9));
		
		
		
		
		
		
		
		
		
	}
	
	
	
	public static String getString(List<Integer> list) {
		return list.stream().map(i -> i% 2 == 0 ? "e"+i : "o"+i).collect(Collectors.joining(","));
	}
	
	
	public static List<String> getList(List<String> list, String indentifier, int size) {
		return list.stream().filter(s -> s.startsWith(indentifier)).filter(s -> s.length() == size).collect(Collectors.toList());
	}
	
	public static List<Integer> rightDigit(List<Integer> nums) {
		  return nums.stream().map(n -> n % 10).collect(Collectors.toList());
		}
	
	public static List<Integer> multiplyTwo(List<Integer> nums){
		return nums.stream().map(n -> n*2).collect(Collectors.toList());
	}
	
	public static  List<String> removeX(List<String> words){
		words.replaceAll(n -> n.replace("x", ""));
		return words;
	}
	
	public static boolean lumpSum(int start, int[] nums, int target) {
		//make sure start is zero
		if(start >= nums.length)
			return target == 0;
		//set your index value to zero
		int i = start;
		int sum = 0;
		//step through while the i is less then you index and equal to your initial value
		while(i < nums.length && nums[start] == nums[i]) {
			//add index to sum
			sum += nums[i];
			//increment sum
			i++;
		}
		
		//update start to index, and target
		if(lumpSum(i,nums,target-sum))
			return true;
		
		if(lumpSum(i, nums, target))
			return true;
		
		return false;
		
		
		
	}
	
	

	
	
	
	

}
