package com.lambda.basic2;

public class ExecuteLambda {
	public static boolean checker(PreformOperation p, int num) {
		return p.check(num);
	}
	
	public static PreformOperation isOdd() {
		return a -> (a % 2 != 0) ? true:false;
		
	}
	
	
	public static PreformOperation isEven() {
		return a -> (a % 2 == 0) ? true:false;
	}
	
	
	public static PreformOperation isPrime() {
		return n -> {
			for(int i = 2; i*i <= n; i++) {
				if(n%i == 0) {
					return false;
				}
			}
			return true; 
		};
	}
	
	
	public static PreformOperation isPalindrome() {
		return n -> n == Integer.parseInt(new StringBuilder(String.valueOf(n)).reverse().toString()) ? true:false;
	}
		
	
}
