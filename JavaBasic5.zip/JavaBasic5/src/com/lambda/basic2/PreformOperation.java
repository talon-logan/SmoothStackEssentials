package com.lambda.basic2;

public interface PreformOperation {
	boolean check(int a);
}
