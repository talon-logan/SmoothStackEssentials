
//time class used to sleep a thread
public class time {
    static void sleep(long millis){
        try{
            Thread.sleep(millis);
        }
        catch(InterruptedException e){
            e.printStackTrace();
        }
    }
}
