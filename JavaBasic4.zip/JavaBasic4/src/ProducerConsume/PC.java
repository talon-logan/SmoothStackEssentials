package ProducerConsume;
import java.util.LinkedList;

public class PC {
    LinkedList<Integer> list = new LinkedList<>();

    int cap = 2;

    public void produce() throws InterruptedException{
        int val = 0;

        while(true){
            synchronized(this){
                while(list.size() == cap){// while list is full wait 
                    wait();
                }
                list.add(val++);

                //notifies consumer thread to stat consuming
                notify();

                Thread.sleep(1000);
            }
        }

    }


    public void consume() throws InterruptedException{
        while (true){
            //
            synchronized(this){
                //consume wait while the list is empty
                while (list.size() == 0)
                    wait();
                //remove the first value
                int val = list.removeFirst();
                //returns the value
                System.out.println("Consumer consumed-"+val);
            }
            //inform the producer thread
            notify();

            Thread.sleep(1000);
        }
    }
}
