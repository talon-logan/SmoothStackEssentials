package test;
import static org.junit.Assert.*;

import org.junit.Test;

import Basics.LineTest.Line;

public class TestLine {
	

	@Test
	public void Slopetest() {
		Line line = new Line(1, 2, 3, 5);
		double reference = 3;
		assertEquals(reference, line.getSlope(),0.001);
		line.sety0(reference);
		assertNotEquals(reference, line.getSlope(),0.001);
	}
	
	@Test
	public void testDistance() {
		Line line = new Line(2,4,3,5);
		double refernce = 5.0;
		assertEquals(refernce, line.getDistance(), 0.01);
		line.setX0(refernce);
		assertNotEquals(refernce, line.getDistance(), 0.01);
		
	}
	
	@Test
	public void testParralle () {
		Line line = new Line(1, 2, 1, 2);
		Line line2 = new Line(0,5,0,5);
		assertEquals(true,line.parallelTo(line2));
		
	}

}
