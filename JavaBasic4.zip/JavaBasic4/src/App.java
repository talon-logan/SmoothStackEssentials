
import ProducerConsume.PC;
public class App {
    public static void main(String[] args) throws Exception {
        //Assignment 1
        Singleton inst1 = new Singleton();
        Singleton inst2 = new Singleton();

        //Assignment 2
        Multithread mt1 = new Multithread();
        mt1.run(); 

       

    

        Shared x = new Shared();
        Shared y = new Shared();

        Thread1 t3 =  new Thread1(x, y);
        t3.start();// thread should loc before t

        Thread2 t4 = new Thread2(x, y);
        t4.start();

        time.sleep(2000);


    }


}
