//this class shares between both threads
public class Shared {
    //first synchronized method
    synchronized void test1(Shared x){
        System.out.println("Test x");// sync
        time.sleep(1000);//then sleep//

        x.test2();//taking object lock of y enters into test2 method
        System.out.println("Test x ends");
    }
    //second syn method
    synchronized void test2(){
        System.out.println("Test 2 begin");
        time.sleep(1000);

        System.out.println("test 2 end");
    }
    
}

class Thread1 extends Thread{
    private Shared x;
    private Shared y;
    //constructor to init fields
    public Thread1(Shared x, Shared y){
        this.x = x;
        this.y = y;
    }
    //method to start thread
    public void run(){
        x.test1(y);// startand calls test1 method by t
    }
}

class Thread2 extends Thread{
    private Shared x;
    private Shared y;
    //constructor to init  fields
    public Thread2(Shared x, Shared y){
        this.x = x;
        this.y = y;
    }

    public void run(){
        y.test1(x);
    }
}
